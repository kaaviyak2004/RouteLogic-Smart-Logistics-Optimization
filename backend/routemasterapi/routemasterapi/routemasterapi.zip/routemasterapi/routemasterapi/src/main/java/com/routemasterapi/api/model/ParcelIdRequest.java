package com.routemasterapi.api.model;

public class ParcelIdRequest {
	private int parcelId;

	public int getParcelId() {
		return parcelId;
	}

	public void setParcelId(int parcelId) {
		this.parcelId = parcelId;
	}

 
	 

}
