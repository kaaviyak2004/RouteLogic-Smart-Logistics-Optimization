package com.routemasterapi.api;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RouteMasterApplication {

	public static void main(String[] args) {
		SpringApplication.run(RouteMasterApplication.class, args);
	}
}